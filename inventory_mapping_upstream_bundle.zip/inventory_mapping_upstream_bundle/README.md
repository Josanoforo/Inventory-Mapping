# Inventory Mapping Upstream Bundle

Este bundle contiene los contratos y schemas diseñados para las fases upstream antes de Inventory Mapping:

- Source Intake
- Data Extraction
- Signal Extraction
- validators y gate a Inventory Mapping

## Estructura

- `upstream/source-intake/contracts/`
- `upstream/source-intake/schemas/`
- `upstream/data-extraction/contracts/`
- `upstream/data-extraction/schemas/`
- `upstream/signal-extraction/contracts/`
- `upstream/signal-extraction/schemas/`

## Contenido

### Source Intake
- `source_intake_contract.md`
- `source_intake_validator.md`
- `source_packet.schema.json`
- `source_intake_validation.schema.json`

### Data Extraction
- `data_extraction_contract.md`
- `data_extraction_validator.md`
- `data_extraction_record.schema.json`
- `data_extraction_validator.schema.json`

### Signal Extraction
- `signal_extraction_contract.md`
- `signal_extraction_validator.md`
- `signal_to_inventory_entry_gate.md`
- `signal_card.schema.json`
- `signal_validation.schema.json`
- `signal_inventory_gate.schema.json`
